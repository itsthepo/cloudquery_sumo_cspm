SELECT 'manual actions required' AS description
