\echo "Administrator and Operator Logs"
\set check_id '1270.09ad1System.12 - 09.ad - 1'
\echo :check_id
\ir ../queries/monitor/activitylog_administrativeoperations_audit.sql
\set check_id '1271.09ad1System.1 - 09.ad - 1'
\echo :check_id
\ir ../queries/monitor/activitylog_administrativeoperations_audit.sql