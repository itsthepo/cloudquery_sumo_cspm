\echo "Back-up"
\set check_id '1616.09l1Organizational.16 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/long-term_geo-redundant_backup_should_be_enabled_for_azure_sql_databases.sql
\set check_id '1617.09l1Organizational.23 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/mysql_servers_without_geo_redundant_backups.sql
\set check_id '1618.09l1Organizational.45 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/postgresql_servers_without_geo_redundant_backups.sql
\set check_id '1619.09l1Organizational.7 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/mariadb_servers_without_geo_redundant_backups.sql
\set check_id '1621.09l2Organizational.1 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/long-term_geo-redundant_backup_should_be_enabled_for_azure_sql_databases.sql
\set check_id '1622.09l2Organizational.23 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/mysql_servers_without_geo_redundant_backups.sql
\set check_id '1623.09l2Organizational.4 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/postgresql_servers_without_geo_redundant_backups.sql
\set check_id '1624.09l3Organizational.12 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/mariadb_servers_without_geo_redundant_backups.sql
\set check_id '1626.09l3Organizational.5 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/postgresql_servers_without_geo_redundant_backups.sql
\set check_id '1627.09l3Organizational.6 - 09.l - 1'
\echo :check_id
\ir ../queries/sql/mariadb_servers_without_geo_redundant_backups.sql
